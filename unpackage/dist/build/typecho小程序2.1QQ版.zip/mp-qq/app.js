// 该程序为阳光艺创站小创果独立开发 
// 小程序使用教程请访问www.i4qq.com进行查看 
// 官方唯一指定交流群：927510477 
// 删除上述文字将不会获得维护 

require('./common/runtime.js')
require('./common/vendor.js')
require('./common/main.js')